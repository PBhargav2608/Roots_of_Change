document.getElementById("showSchemesBtn").addEventListener("click", function() {
  document.getElementById("stateSelection").style.display = "block";
});

document.getElementById("showStateSchemesBtn").addEventListener("click", function() {
  var selectedState = document.getElementById("stateSelect").value;
  var stateSchemesDiv = document.getElementById("stateSchemes");
  
  // Clear previous schemes if any
  stateSchemesDiv.innerHTML = "";

  // Define example schemes and requirements for Andhra Pradesh and Telangana
  var schemes = {
      "Andhra Pradesh": [
          { name: "Amma Vodi Scheme", requirements: "Must be a mother of school-going children." },
          { name: "YSR Cheyutha Scheme", requirements: "Women aged between 45 to 60 years are eligible." }
      ],
      "Telangana": [
          { name: "Rythu Bandhu Scheme", requirements: "Must be a farmer holding cultivable land." },
          { name: "KCR Kit Scheme", requirements: "Expectant mothers are eligible." }
      ]
      
  };

  // Check if the selected state has schemes defined
  if (selectedState in schemes) {
      var schemesList = "<ul>";
      schemes[selectedState].forEach(function(scheme) {
          schemesList += "<li><strong>" + scheme.name + ":</strong> " + scheme.requirements + "</li>";
      });
      schemesList += "</ul>";
      stateSchemesDiv.innerHTML = "<p>Schemes for " + selectedState + ":</p>" + schemesList;
  } else {
      stateSchemesDiv.innerHTML = "<p>No schemes found for " + selectedState + ".</p>";
  }
});
